# Lambda

## zip

```shell
yarn zip
```